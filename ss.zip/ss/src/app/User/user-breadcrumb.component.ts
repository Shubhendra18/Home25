import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-breadcrumb',
  templateUrl: './user-breadcrumb.component.html',
  styles: []
})
export class UserBreadcrumbComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

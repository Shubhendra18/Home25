import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-send',
  templateUrl: './user-send.component.html',
  styles: []
})
export class UserSendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-draft',
  templateUrl: './user-draft.component.html',
  styles: []
})
export class UserDraftComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
